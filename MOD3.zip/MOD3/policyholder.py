class Policyholder:
    def __init__(self, policyholder_id, name, status='active'):
        self.policyholder_id = policyholder_id
        self.name = name
        self.status = status
        self.products = []
        self.payments = []

    def register_product(self, product):
        if self.status == 'active':
            self.products.append(product)
        else:
            print(f"Cannot register product: {self.name} is suspended.")

    def suspend(self):
        self.status = 'suspended'

    def reactivate(self):
        self.status = 'active'

    def display_details(self):
        return {
            'ID': self.policyholder_id,
            'Name': self.name,
            'Status': self.status,
            'Products': [product.name for product in self.products],
            'Payments': [payment.amount for payment in self.payments],
        }
