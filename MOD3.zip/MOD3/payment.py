class Payment:
    def __init__(self, payment_id, policyholder_id, amount, status='pending'):
        self.payment_id = payment_id
        self.policyholder_id = policyholder_id
        self.amount = amount
        self.status = status

    def process_payment(self):
        self.status = 'completed'

    def add_penalty(self, penalty_amount):
        self.amount += penalty_amount

    def send_reminder(self):
        print(f"Reminder sent for payment of {self.amount} by Policyholder ID: {self.policyholder_id}")
