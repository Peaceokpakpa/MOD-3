from policyholder import Policyholder
from product import Product
from payment import Payment

# Creating Products
life_insurance = Product(1, "Life Insurance", 500)
health_insurance = Product(2, "Health Insurance", 300)

# Creating Policyholders
john = Policyholder(1, "John Doe")
jane = Policyholder(2, "Jane Smith")

# Register Products
john.register_product(life_insurance)
jane.register_product(health_insurance)

# Creating Payments
payment1 = Payment(1, john.policyholder_id, life_insurance.premium)
payment2 = Payment(2, jane.policyholder_id, health_insurance.premium)

# Process Payments
payment1.process_payment()
payment2.process_payment()

# Adding Payments to Policyholders
john.payments.append(payment1)
jane.payments.append(payment2)

# Display Details
print(john.display_details())
print(jane.display_details())
